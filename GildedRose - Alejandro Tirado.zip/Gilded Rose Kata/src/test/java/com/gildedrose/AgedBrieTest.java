package com.gildedrose;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AgedBrieTest extends ItemsTest{

    @Test
    void foo() {
        Item[] items = new Item[] { new Item("foo", 0, 0) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertEquals("foo", app.getItems()[0].name);
    }

    @Test
    public void item_AgedBrie_increasesInQuality() {

        Item[] items = new Item[] { new Item("Aged Brie", 2, 2) };
        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("Aged Brie", 1, 3));
    }

    @Test
    public void item_AgedBrie_increasesInQuality_DoublesWhenOff() {

        Item[] items = new Item[] { new Item("Aged Brie", 0, 2) };
        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("Aged Brie", -1, 4));
    }

    @Test
    public void item_AgedBrie_cannotGoOver50Quality() {

        Item[] items = new Item[] {new Item("Aged Brie", 2, 50)};

        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("Aged Brie", 1, 50));
    }




}
