package com.gildedrose;

import org.junit.jupiter.api.Test;

public class BackStagePassesTest extends ItemsTest {

    @Test
    public void item_BackStagePasses_increasesInQuality_byOneOutside10Days() {

        Item[] items = new Item[] {new Item("Backstage passes to a TAFKAL80ETC concert", 20, 2)};

        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("Backstage passes to a TAFKAL80ETC concert", 19, 3));
    }

    @Test
    public void item_BackStagePasses_increasesInQuality_byTwoInside10Days() {

        Item[] items = new Item[] {new Item("Backstage passes to a TAFKAL80ETC concert", 10, 2)};

        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("Backstage passes to a TAFKAL80ETC concert", 9, 4));
    }

    @Test
    public void item_BackStagePasses_increasesInQuality_byThreeInside5Days() {

        Item[] items = new Item[] {new Item("Backstage passes to a TAFKAL80ETC concert", 5, 2)};

        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("Backstage passes to a TAFKAL80ETC concert", 4, 5));
    }

    @Test
    public void item_BackStagePasses_increasesInQuality_goesToZeroWhenSellInExpires() {

        Item[] items = new Item[] {new Item("Backstage passes to a TAFKAL80ETC concert", 0, 20)};

        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("Backstage passes to a TAFKAL80ETC concert", -1, 0));
    }

}
