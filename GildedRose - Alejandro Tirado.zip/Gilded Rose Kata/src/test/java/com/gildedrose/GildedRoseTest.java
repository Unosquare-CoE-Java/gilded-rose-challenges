package com.gildedrose;

import org.junit.jupiter.api.Test;

public class GildedRoseTest extends ItemsTest {

    @Test
    public void sellInDateDecreases_butQualityCannotBeNegative() {

        Item[] items = new Item[]{new Item("foo", 0, 0)};
        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("foo", -1, 0));
    }

    @Test
    public void qualityDecreases() {

        Item[] items = new Item[]{new Item("foo", 10, 10)};

        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("foo", 9, 9));
    }

    @Test
    public void qualityDecreasesFasterAfterSellInDateExpired() {

        Item[] items = new Item[] {new Item("foo", 0, 10)};

        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("foo", -1, 8));
    }

}
