package com.gildedrose;

import org.junit.jupiter.api.Test;

public class ConjuredItemTest extends ItemsTest {

    @Test
    public void item_conjured_decreasesInQuality_twiceTheSpeed() {

        Item[] items = new Item[] {new Item("Conjured Mana Cake", 3, 6)};
        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("Conjured Mana Cake", 2, 4));
    }

    @Test
    public void item_conjured_decreasesInQuality_twiceTheSpeed_alsoWhenSellInExpired() {

        Item[] items = new Item[] {new Item("Conjured Mana Cake", 0, 6)};
        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("Conjured Mana Cake", -1, 2));
    }

}
