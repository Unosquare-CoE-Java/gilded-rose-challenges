package com.gildedrose;

import static org.junit.jupiter.api.Assertions.assertEquals;

public abstract class ItemsTest {
    public void assertItems(Item actual, Item expected) {
        assertEquals(expected.name, actual.name);
        assertEquals(expected.quality, actual.quality);
        assertEquals(expected.sellIn, actual.sellIn);
    }
}
