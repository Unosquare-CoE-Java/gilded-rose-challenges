package com.gildedrose;

import org.junit.jupiter.api.Test;

public class SulfurasTest extends ItemsTest {

    @Test
    public void item_Sulfuras_neverChanges() {

        Item[] items = new Item[]{new Item("Sulfuras, Hand of Ragnaros", 100, 100)};

        GildedRose app = new GildedRose(items);

        app.updateQuality();

        assertItems(app.getItems()[0], new Item("Sulfuras, Hand of Ragnaros", 100, 100));
    }

}
