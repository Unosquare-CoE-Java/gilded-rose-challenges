package com.gildedrose;

class GildedRose {

    // Product Item Names
    private final String AGED_BRIE = "Aged Brie";
    private final String SULFURAS = "Sulfuras, Hand of Ragnaros";
    private final String BACKSTAGE_PASSES = "Backstage passes to a TAFKAL80ETC concert";
    private final String CONJURED = "Conjured";

    // Dataset of Products
    private final Item[] items;

    // Constructor
    public GildedRose(Item[] items) {
        this.items = items;
    }

    public void updateQuality() {
        for(Item item: this.items) {
            updateItemQuality(item);
        }
    }

    // Main method to change each object
    private void updateItemQuality(Item item) {

        boolean hasSellByDate = !item.name.equals(SULFURAS);
        boolean isExpired = item.sellIn < 1;
        int degradeRate = getDegradeRate(item, isExpired);

        boolean doesDegrade = !item.name.equals(AGED_BRIE) &&
                              !item.name.equals(BACKSTAGE_PASSES) &&
                              !item.name.equals(SULFURAS);

        if (doesDegrade) {
            adjustQuality(item, degradeRate);
        }

        if (item.name.equals(AGED_BRIE)) {
            int adjustment = isExpired ? 2: 1;
            adjustQuality(item, adjustment);
        }

        if (item.name.equals(BACKSTAGE_PASSES)) {
            updateBackstagePassQuality(item, isExpired);
        }

        if (hasSellByDate) {
            item.sellIn = item.sellIn - 1;
        }

    }

    private void updateBackstagePassQuality(Item item, boolean isExpired) {
        adjustQuality(item, 1);
        if (item.sellIn < 11) {
            adjustQuality(item, 1);
        }
        if (item.sellIn < 6) {
            adjustQuality(item, 1);
        }
        if (isExpired){
            item.quality = item.quality - item.quality;
        }
    }

    private int getDegradeRate(Item item, boolean isExpired) {
        int baseDegradeRate = item.name.contains(CONJURED) ? -2 : -1;
        return isExpired ? baseDegradeRate * 2 : baseDegradeRate;
    }

    private void adjustQuality(Item item, int adjustment) {
        int newQuality = item.quality + adjustment;
        boolean isInRange = newQuality <= 50 && newQuality >= 0;
        if (isInRange) {
            item.quality = newQuality;
        }
    }
    public Item[] getItems() {
        return items;
    }

}
