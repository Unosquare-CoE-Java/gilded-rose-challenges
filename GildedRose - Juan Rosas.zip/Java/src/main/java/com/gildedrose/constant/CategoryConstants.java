package com.gildedrose.constant;

public class CategoryConstants {
    //Constants containing Categories with a different behavior
    public static final String AGED_BRIE = "Aged Brie";
    public static final String BACKSTAGE_PASSES = "Backstage passes to a TAFKAL80ETC concert";
    public static final String SULFURAS = "Sulfuras, Hand of Ragnaros";
    //New category
    public static final String CONJURED = "Conjured Mana Cake";
    private CategoryConstants(){

    }
}
