package com.gildedrose.entity;

import com.gildedrose.Item;

public class DefaultCategory extends Category {
    public DefaultCategory(Item item){
        this.item = item;
    }
    @Override
    public void update() {
        removeQuality();
        removeDay();
        if (isSellInNegative()){
            // Once the sell by date has passed (isSellNegative = True), Quality degrades twice as fast
            removeQuality();
        }
    }
}
