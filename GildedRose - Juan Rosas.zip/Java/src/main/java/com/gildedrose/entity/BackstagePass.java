package com.gildedrose.entity;

import com.gildedrose.Item;

public class BackstagePass extends Category {
    public BackstagePass(Item item){
        this.item = item;
    }

    @Override
    public void update() {
        addQuality();
        //Quality  increases by 2 (Again) if we have  10 days or less to sell
        if (item.sellIn < 11) {
            addQuality();
        }

        //Quality  increasess by 3  (Again) if there are 5 days or lesss to sell
        if (item.sellIn < 6) {
            addQuality();
        }
        //default remove 1 day
        removeDay();
        //Quality drops to 0
        if (isSellInNegative()){
            item.quality = item.quality - item.quality;
        }
    }

}
