package com.gildedrose.entity;

import com.gildedrose.Item;

public class AgedBrie extends Category{

    public AgedBrie(Item item){
        this.item = item;
    }

    @Override
    public void update() {
        addQuality();
        removeDay();
        if (isSellInNegative()) addQuality();
    }

}
