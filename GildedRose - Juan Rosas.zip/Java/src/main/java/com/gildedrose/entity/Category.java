package com.gildedrose.entity;

import com.gildedrose.Item;

public abstract class Category {
    Item item;
    public abstract void update();

    void addQuality() {
        if (item.quality<50) item.quality++;
    }

    boolean isSellInNegative() {
        return  item.sellIn<0;
    }

    void removeDay() {
        item.sellIn--;
    }
    void removeQuality(){
        //Quality cant be negative
        if (item.quality>0){
            item.quality--;
        }

    }
}
