package com.gildedrose.entity;

import com.gildedrose.Item;

public class Sulfuras extends Category{
    public Sulfuras(Item item){
        this.item = item;
    }
    @Override
    public void update() {
        addQuality();
    }
}
