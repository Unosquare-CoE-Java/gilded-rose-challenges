package com.gildedrose.entity;

import com.gildedrose.Item;

public class Conjured extends Category{

    public Conjured(Item item){
        this.item = item;
    }

    @Override
    public void update() {
        //Conjured items degrade in Quality twice as fast as normal items
        removeQuality();
        removeQuality();
        removeDay();
        // Once the sell by date has passed, Quality degrades twice as fast
        if (isSellInNegative()){
            removeQuality();
            removeQuality();
        }
    }
}
