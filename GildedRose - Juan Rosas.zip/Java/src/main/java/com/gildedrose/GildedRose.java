package com.gildedrose;

import com.gildedrose.constant.CategoryConstants;
import com.gildedrose.entity.*;

class GildedRose {

    Item[] items;

    public GildedRose(Item[] items) {
        this.items = items;
    }

    public void updateQuality() {
        for (int i = 0; i < items.length; i++) {
            switch (items[i].name){
                case CategoryConstants.AGED_BRIE:
                   new AgedBrie(items[i]).update();
                    break;

                case CategoryConstants.BACKSTAGE_PASSES:
                   new BackstagePass(items[i]).update();
                    break;

                case CategoryConstants.SULFURAS:
                    new Sulfuras(items[i]).update();
                    break;

                case CategoryConstants.CONJURED:
                   new Conjured(items[i]).update();
                    break;

                default:
                    new DefaultCategory(items[i]).update();

            }

        }
    }

}
