package com.gildedrose;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GildedRoseTest {

    @Test
    void foo() {
        Item[] items = new Item[] {
            new Item("+5 Dexterity Vest", 10, 20), //
            new Item("Aged Brie", 2, 0), //
            new Item("Elixir of the Mongoose", 5, 7), //
            new Item("Sulfuras, Hand of Ragnaros", 0, 49), //
            new Item("Sulfuras, Hand of Ragnaros", -1, 80),
            new Item("Backstage passes to a TAFKAL80ETC concert", 15, 20),
            new Item("Backstage passes to a TAFKAL80ETC concert", 10, 48),
            new Item("Backstage passes to a TAFKAL80ETC concert", 5, 49),
            // this conjured item does not work properly yet
            new Item("Conjured Mana Cake", 3, 6) };

        GildedRose app = new GildedRose(items);
        app.updateQuality();
        //Default should decrease 1 sellIn and quality
        assertEquals("+5 Dexterity Vest", app.items[0].name);
        assertEquals(9, app.items[0].sellIn);
        assertEquals(19, app.items[0].quality);
        //Aged brie decrease sellIn add quality
        assertEquals("Aged Brie", app.items[1].name);
        assertEquals(1, app.items[1].sellIn);
        assertEquals(1, app.items[1].quality);

        //Sulfuras add quality sellIn equal
        assertEquals("Sulfuras, Hand of Ragnaros", app.items[3].name);
        assertEquals(0, app.items[3].sellIn);
        assertEquals(50, app.items[3].quality);

        //Backstage sellIn < 11 add 2 quality
        assertEquals("Backstage passes to a TAFKAL80ETC concert", app.items[6].name);
        assertEquals(9, app.items[6].sellIn);
        assertEquals(50, app.items[6].quality);

        //Conjured decrease twice as normal -2 quality
        assertEquals("Conjured Mana Cake", app.items[8].name);
        assertEquals(2, app.items[8].sellIn);
        assertEquals(4, app.items[8].quality);

    }

}
