package com.gildedrose;

import com.gildedrose.model.Item;
import com.gildedrose.util.Constants;
import com.gildedrose.util.GildedRoseUtil;

public class GildedRose {


    Item[] items;

    public GildedRose(Item[] items) {
        this.items = items;
    }

    public void updateQuality(){
        for (int x = 0; x < items.length; x++) {
            Item evaluatedItem = items[x];
            if (Constants.AGED_BRIE.equals(evaluatedItem.name)) {
                GildedRoseUtil.updateAgedBrie(evaluatedItem);
            }else if(Constants.SULFURES.equals(evaluatedItem.name)){
                GildedRoseUtil.updateSulfures(evaluatedItem);
            }else if(Constants.BACKSTAGE_ENTRANCE.equals(evaluatedItem.name)){
                GildedRoseUtil.updateBackstageEntrance(evaluatedItem);
            }else if(Constants.CONJURED_MAGIC.equals(evaluatedItem.name)){
                GildedRoseUtil.updateConjured(evaluatedItem);
            }else{
                GildedRoseUtil.updateOther(evaluatedItem);
            }
        }
    }
}
