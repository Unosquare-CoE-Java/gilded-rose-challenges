package com.gildedrose.util;

import com.gildedrose.model.Item;

public class GildedRoseUtil{

    private static final int MAX_QUALITY_LIMIT = 50;
    private static final int MIN_QUALITY_LIMIT = 0;

    private GildedRoseUtil(){

    }

    public static boolean maxQualityLimit(int quality){
        return quality > MAX_QUALITY_LIMIT;
    }

    public static boolean minQualityLimit(int quality){
        return quality > MIN_QUALITY_LIMIT;
    }

    public static void updateConjured(Item item){
        int quality = item.quality;
        int daySellIn = item.sellIn;

        quality -= 2;
        daySellIn -= 1;

        if(daySellIn<0){
            quality -=2;
        }

        item.quality = minQualityLimit( quality)?quality:MIN_QUALITY_LIMIT;
        item.sellIn = daySellIn;
    }

    public static void updateBackstageEntrance(Item item){
        int quality = item.quality;
        int daySellIn = item.sellIn;

        quality = quality + 1;

        if(daySellIn< 11) {

            quality = quality + 1;
            item.quality = quality;
        }

        if(daySellIn <6 ){
            quality = quality + 1;
            item.quality = quality;
        }

        daySellIn = daySellIn-1;
        item.sellIn = daySellIn;

        if(daySellIn<0){
            item.quality = 0;
        }else{
            if(item.quality>=50){
                item.quality = 50;
            }else{
                item.quality = quality;
            }
        }
    }

    public static void updateAgedBrie(Item item){
        int quality = item.quality;
        int daySellIn = item.sellIn;

        daySellIn -= 1;
        if (daySellIn >= 0) {
            quality += 1;
        } else {
            quality += 2;
        }
        item.sellIn = daySellIn;
        item.quality = maxQualityLimit(quality) ? MAX_QUALITY_LIMIT : quality;
    }

    public static void updateSulfures(Item item){
        //doing nothing
    }

    public static void updateOther(Item item){
        int quality = item.quality;
        int daySellIn = item.sellIn;

        quality -= 1;
        daySellIn -= 1;

        if(daySellIn<0){
            quality -=1;
        }

        item.quality = minQualityLimit( quality)?quality:MIN_QUALITY_LIMIT;
        item.sellIn = daySellIn;
    }
}
