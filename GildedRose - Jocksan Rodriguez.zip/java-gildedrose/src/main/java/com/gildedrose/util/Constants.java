package com.gildedrose.util;

public class Constants {

    public static final String AGED_BRIE ="Aged Brie";
    public static final String SULFURES ="Sulfuras, Hand of Ragnaros";
    public static final String BACKSTAGE_ENTRANCE = "Backstage passes to a TAFKAL80ETC concert";
    public static final String CONJURED_MAGIC = "Conjured Mana Cake";

    private Constants(){

    }
}
