package com.gildedrose;

import com.gildedrose.model.Item;
import com.gildedrose.util.Constants;

public class TexttestFixture {
    public static void main(String[] args) {
        Item[] items = new Item[] {
                new Item("+5 Dexterity Vest", 10, 20),
                new Item(Constants.AGED_BRIE, 2, 0),
                new Item("Elixir of the Mongoose", 5, 7),
                new Item(Constants.SULFURES, 0, 80),
                new Item(Constants.SULFURES, -1, 80),
                new Item(Constants.BACKSTAGE_ENTRANCE, 15, 20),
                new Item(Constants.BACKSTAGE_ENTRANCE, 10, 49),
                new Item(Constants.BACKSTAGE_ENTRANCE, 5, 49),
                new Item(Constants.CONJURED_MAGIC, 3, 6)
        };

        GildedRose app = new GildedRose(items);

        int days =25;
        if (args.length > 0) {
            days = Integer.parseInt(args[0]) + 1;
        }

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            for (Item item : items) {
                System.out.println(item);
            }
            System.out.println();
            app.updateQuality();
        }
    }

}
