package com.gildedrose;

import com.gildedrose.model.Item;
import com.gildedrose.util.Constants;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GildedRoseTest {

    @Test
    void testAgedBrie() {
        evaluateItem(new Item(Constants.AGED_BRIE, 2, 0),
            24,
            Constants.AGED_BRIE,
            -22,
            46);
    }

    @Test
    void testSulfures(){
        int sellIn = -1;
        int quality = 80;
        evaluateItem(new Item(Constants.SULFURES, sellIn, quality),
            25,
            Constants.SULFURES,
            sellIn,
            quality);
    }

    @Test
    void testBackstageEntrance(){
        evaluateItem(new Item(Constants.BACKSTAGE_ENTRANCE, 10, 49),
            11,
            Constants.BACKSTAGE_ENTRANCE,
            -1,
            0
            );
    }

    @Test
    void testConjured(){
        evaluateItem(new Item(Constants.CONJURED_MAGIC,3,6),
            24,
            Constants.CONJURED_MAGIC,
            -21,
            0
            );
    }

    @Test
    void testOtherItem(){

        evaluateItem(new Item(null, 10, 20),
            24,
            null,
            -14,
            0);
    }

    private void evaluateItem(Item item, int evaluatedDay, String expName, int expSellIn, int expQuality ){
        Item[] items = new Item[] {item};
        GildedRose app = new GildedRose(items);

        for(int x=0; x<=evaluatedDay;x++){

            if(x==evaluatedDay) {
                if(expName != null){
                    assertEquals(expName, app.items[0].name);
                }
                assertEquals(expSellIn, app.items[0].sellIn);
                assertEquals(expQuality, app.items[0].quality);
            }
            app.updateQuality();
        }
    }
}
