package com.gildedrose;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GildedRoseTest {

    GildedRose gildedRose;
    Item[] items;

    /**
     * Method to validate the Normal Items behavior on sell date.
     * Note. This method is to validate the already defined functionality of the app.
     */
    @Test
    void test_normalItemsDegrade_onSellDate() {
        int sellIn = 5;
        int days = 5;

        int quality1 = 25;
        int quality2 = 5;
        int quality3 = 0;

        Item[] items = new Item[] {
            new Item("+5 Dexterity Vest", sellIn, quality1),
            new Item("Elixir of the Mongoose", sellIn, quality2),
            new Item("Elixir of the Mongoose", sellIn, quality3),
        };

        gildedRose = new GildedRose(items);

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            gildedRose.updateQuality();
        }

        assertEquals( sellIn-days, gildedRose.listItems.get(0).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(1).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(2).sellIn);

        assertEquals(20, gildedRose.listItems.get(0).quality);
        assertEquals(0, gildedRose.listItems.get(1).quality);
        assertEquals(0, gildedRose.listItems.get(2).quality);

    }

    /**
     * Method to validate the Normal Items behavior after the sell date.
     * Note. This method is to validate the already defined functionality of the app.
     */
    @Test
    void test_normalItems_afterSellDate() {
        int days = 10;

        int sellInDexterity = 10;
        int sellInElixir = 5;

        int qualityDexterity = 20;
        int qualityElixir = 37;

        Item[] items = new Item[] {
            new Item("+5 Dexterity Vest", sellInDexterity, qualityDexterity), //
            new Item("Elixir of the Mongoose", sellInElixir, qualityElixir), //
        };

        gildedRose = new GildedRose(items);

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            System.out.println();
            gildedRose.updateQuality();
        }

        assertEquals(sellInDexterity-days, gildedRose.listItems.get(0).sellIn);
        assertEquals(sellInElixir-days, gildedRose.listItems.get(1).sellIn);

        assertEquals(10, gildedRose.listItems.get(0).quality);
        assertEquals(22, gildedRose.listItems.get(1).quality);

    }

    /**
     * Method to validate the Aged Brie Items behavior on sell date.
     * Note. This method is to validate the already defined functionality of the app.
     */
    @Test
    void test_agedBrieItemOnSellDate() {

        int days = 20;

        int sellIn = 20;

        int quality0 = 50;
        int quality1 = 20;
        int quality2 = 0;

        Item[] items = new Item[] {

            new Item("Aged Brie", sellIn, quality1), //
            new Item("Aged Brie", sellIn, quality2), //
            new Item("Aged Brie", sellIn, quality0) //
        };

        gildedRose = new GildedRose(items);

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            System.out.println();
            gildedRose.updateQuality();
        }

        assertEquals( sellIn-days, gildedRose.listItems.get(0).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(1).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(2).sellIn);

        assertEquals(40, gildedRose.listItems.get(0).quality);
        assertEquals(20, gildedRose.listItems.get(1).quality);
        assertEquals(50, gildedRose.listItems.get(2).quality);
    }

    /**
     * Method to validate the Aged Brie Items behavior after sell date.
     * Note. This method is to validate the already defined functionality of the app.
     */
    @Test
    void test_agedBrieItemAfterSellDate() {
        int sellIn = 5;
        int days = 10;

        int quality0 = 50;
        int quality6 = 20;
        int quality10 = 0;

        Item[] items = new Item[] {
            new Item("Aged Brie", sellIn, quality6), //
            new Item("Aged Brie", sellIn, quality10), //
            new Item("Aged Brie", sellIn, quality0) //
        };

        gildedRose = new GildedRose(items);



        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            System.out.println();
            gildedRose.updateQuality();
        }

        assertEquals( sellIn-days, gildedRose.listItems.get(0).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(1).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(2).sellIn);

        assertEquals(35, gildedRose.listItems.get(0).quality);
        assertEquals(15, gildedRose.listItems.get(1).quality);
        assertEquals(50, gildedRose.listItems.get(2).quality);
    }

    /**
     * Method to validate the Sulfuras Items behavior after and on sell date.
     * Note. This method is to validate the already defined functionality of the app.
     */
    @Test
    void test_validateSulfuras_onSellDAte_andAfterSellDAte(){

        int days = 5;

        int sellIn1 = 0;
        int sellIn3 = 15;
        int sellIn4 = -15;
        int qualitySulfuras = 80;

        Item[] items = new Item[] {
            new Item("Sulfuras, Hand of Ragnaros", sellIn1, qualitySulfuras), //
            new Item("Sulfuras, Hand of Ragnaros", sellIn3, qualitySulfuras), //
            new Item("Sulfuras, Hand of Ragnaros", sellIn4, qualitySulfuras)
        };

        gildedRose = new GildedRose(items);

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            System.out.println();
            gildedRose.updateQuality();
        }

        assertEquals( sellIn1 , gildedRose.listItems.get(0).sellIn );
        assertEquals( sellIn3 , gildedRose.listItems.get(1).sellIn );
        assertEquals( sellIn4 , gildedRose.listItems.get(2).sellIn );


        assertEquals( qualitySulfuras , gildedRose.listItems.get(0).quality );
        assertEquals( qualitySulfuras , gildedRose.listItems.get(1).quality );
        assertEquals( qualitySulfuras , gildedRose.listItems.get(2).quality );
    }

    /**
     * Method to validate the Backstage Items behavior before sell date.
     * Note. This method is to validate the already defined functionality of the app.
     */
    @Test
    void test_backstage_beforeSellDate(){

        int days = 20;

        int sellIn = 20;

        int quality3 = 20;
        int quality4 = 10;
        int quality5 = 5;
        int quality6 = 0;

        Item[] items = new Item[] {
            new Item("Backstage passes to a TAFKAL80ETC concert", sellIn, quality3),
            new Item("Backstage passes to a TAFKAL80ETC concert", sellIn, quality4),
            new Item("Backstage passes to a TAFKAL80ETC concert", sellIn, quality5),
            new Item("Backstage passes to a TAFKAL80ETC concert", sellIn, quality6),

        };

        gildedRose = new GildedRose(items);

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            for (Item item : items) {
                System.out.println(item);
            }
            System.out.println();
            gildedRose.updateQuality();
        }

        System.out.println("-------- day " + days + " --------");
        System.out.println("name, sellIn, quality");
        for (Item item : items) {
            System.out.println(item);
        }

        assertEquals( sellIn-days, gildedRose.listItems.get(0).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(1).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(2).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(3).sellIn);


        assertEquals(50, gildedRose.listItems.get(0).quality);
        assertEquals(45, gildedRose.listItems.get(1).quality);
        assertEquals(40, gildedRose.listItems.get(2).quality);
        assertEquals(35, gildedRose.listItems.get(3).quality);

    }

    /**
     * Method to validate the Backstage Items behavior after sell date.
     * Note. This method is to validate the already defined functionality of the app.
     */
    @Test
    void test_backstage_afterSellDate(){
        int days = 21;

        int sellIn = 20;

        int quality3 = 20;
        int quality4 = 10;
        int quality5 = 5;
        int quality6 = 0;

        Item[] items = new Item[] {
            new Item("Backstage passes to a TAFKAL80ETC concert", sellIn, quality3),
            new Item("Backstage passes to a TAFKAL80ETC concert", sellIn, quality4),
            new Item("Backstage passes to a TAFKAL80ETC concert", sellIn, quality5),
            new Item("Backstage passes to a TAFKAL80ETC concert", sellIn, quality6),

        };

        gildedRose = new GildedRose(items);

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            System.out.println();
            gildedRose.updateQuality();
        }

        assertEquals(sellIn-days, gildedRose.listItems.get(0).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(1).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(2).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(3).sellIn);


        assertEquals(0, gildedRose.listItems.get(0).quality);
        assertEquals(0, gildedRose.listItems.get(1).quality);
        assertEquals(0, gildedRose.listItems.get(2).quality);
        assertEquals(0, gildedRose.listItems.get(3).quality);

    }

    /**
     * Method to validate the Conjured Items behavior on sell date.
     * Note. This method is to validate the new functionality of the app.
     */
    @Test
    void test_conjuredItems_onSellDAte(){
        int days = 20;

        int sellIn = 20;

        int quality0 = 50;
        int quality1 = 45;
        int quality2 = 40;
        int quality3 = 35;
        int quality4 = 30;
        int quality5 = 25;
        int quality6 = 20;

        Item[] items = new Item[] {
            new Item("Conjured Mana Cake", 20, quality0),
            new Item("Conjured Mana Cake", 20, quality1),
            new Item("Conjured Mana Cake", 20, quality2),
            new Item("Conjured Mana Cake", 20, quality3),
            new Item("Conjured Mana Cake", 20, quality4),
            new Item("Conjured Mana Cake", 20, quality5),
            new Item("Conjured Mana Cake", 20, quality6),


        };

        gildedRose = new GildedRose(items);

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            System.out.println();
            gildedRose.updateQuality();
        }

        assertEquals( sellIn-days, gildedRose.listItems.get(0).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(1).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(2).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(3).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(4).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(5).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(6).sellIn);

        assertEquals(10, gildedRose.listItems.get(0).quality);
        assertEquals(5, gildedRose.listItems.get(1).quality);
        assertEquals(0, gildedRose.listItems.get(2).quality);
        assertEquals(0, gildedRose.listItems.get(3).quality);
        assertEquals(0, gildedRose.listItems.get(4).quality);
        assertEquals(0, gildedRose.listItems.get(5).quality);
        assertEquals(0, gildedRose.listItems.get(6).quality);

    }

    /**
     * Method to validate the Conjured Items behavior after sell date.
     * Note. This method is to validate the new functionality of the app.
     */
    @Test
    void test_conjuredItems_afterSellDAte(){
        int days = 18;

        int sellIn = 10;

        int quality0 = 50;
        int quality1 = 45;
        int quality2 = 40;
        int quality3 = 35;
        int quality4 = 30;
        int quality5 = 25;
        int quality6 = 20;

        Item[] items = new Item[] {
            new Item("Conjured Mana Cake", sellIn, quality0),
            new Item("Conjured Mana Cake", sellIn, quality1),
            new Item("Conjured Mana Cake", sellIn, quality2),
            new Item("Conjured Mana Cake", sellIn, quality3),
            new Item("Conjured Mana Cake", sellIn, quality4),
            new Item("Conjured Mana Cake", sellIn, quality5),
            new Item("Conjured Mana Cake", sellIn, quality6),
        };

        gildedRose = new GildedRose(items);

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            System.out.println();
            gildedRose.updateQuality();
        }

        assertEquals( sellIn-days, gildedRose.listItems.get(0).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(1).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(2).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(3).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(4).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(5).sellIn);
        assertEquals( sellIn-days, gildedRose.listItems.get(6).sellIn);

        assertEquals(0, gildedRose.listItems.get(0).quality);
        assertEquals(0, gildedRose.listItems.get(1).quality);
        assertEquals(0, gildedRose.listItems.get(2).quality);
        assertEquals(0, gildedRose.listItems.get(3).quality);
        assertEquals(0, gildedRose.listItems.get(4).quality);
        assertEquals(0, gildedRose.listItems.get(5).quality);
        assertEquals(0, gildedRose.listItems.get(6).quality);

    }

}
