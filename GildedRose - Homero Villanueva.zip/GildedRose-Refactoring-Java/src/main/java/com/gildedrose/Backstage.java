package com.gildedrose;

public class Backstage extends Item {
    public Backstage(String name, int sellIn, int quality) {
        super(name, sellIn, quality);
    }

    public void updateQuality() {
        int calculateDegrades = 0;
        --this.sellIn;
        if(this.sellIn >= 0){
            if(this.quality < 50 ){
                if(this.sellIn < 5 && this.sellIn >= 0 ){
                    calculateDegrades = (this.quality+3);
                    this.quality = (calculateDegrades <= 50) ? calculateDegrades: 50;
                }else if(this.sellIn < 10 && this.sellIn >= 5 && this.quality < 49){
                    this.quality = this.quality+2;
                }else{
                    ++this.quality;
                }
            }
        }else{
            this.quality = 0;
        }
    }
}
