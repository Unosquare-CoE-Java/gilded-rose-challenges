package com.gildedrose;

import java.util.ArrayList;
import java.util.List;

class GildedRose {
    Item[] items;
    List<Item> listItems;

    public GildedRose(Item[] items) {
        this.items = items;
        this.listItems = new ArrayList<>();

        for(Item item : items){
            if(item.name.equals("Aged Brie")){
                listItems.add(new AgedBrie(item.name, item.sellIn, item.quality));
            }else if(item.name.equals("Backstage passes to a TAFKAL80ETC concert")){
                listItems.add(new Backstage(item.name, item.sellIn, item.quality));
            }else if(item.name.equals("Conjured Mana Cake")){
                listItems.add(new Conjured(item.name, item.sellIn, item.quality));
            }else if(!item.name.equals("Sulfuras, Hand of Ragnaros")){
                listItems.add(new NormalItem(item.name, item.sellIn, item.quality));
            }else{
                listItems.add(new Item(item.name, item.sellIn, item.quality));
            }
        }
    }

    public void updateQuality() {
        for( Item item : listItems ){
            if(item instanceof AgedBrie){
                ((AgedBrie)item).updateQuality();
            }else if(item instanceof Backstage){
                ((Backstage)item).updateQuality();
            }else if(item instanceof  Conjured){
                ((Conjured)item).updateQuality();
            }else if(item instanceof NormalItem){
                ((NormalItem)item).updateQuality();
            }
        }
    }
}
